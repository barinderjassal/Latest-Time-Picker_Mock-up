/**
 * Created by leon on 5/19/14.
 */

/*
 * defineRequirements - These are the loaders for all of the modules, or packages needed
 * angularRequirements - This is the list of module names that will be feed into the app
 */
var defineRequirements = [
    'angular',
    'angularBootstrap',
    'moment',
    'moduleLoader',
    'sampleLoader',
	'notifier_service',
	'core_component'
], angularRequirements = [
    'ui.bootstrap',
    'TimePicker',
    'SampleTimePickerView',
	'Notifier',
	'CoreComponent'
];

define('app', defineRequirements, function (angular) {
    var app = angular.module('app', angularRequirements);
});