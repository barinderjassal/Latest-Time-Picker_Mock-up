/**
 * Created by Krishnaraj on 1/19/15.
 * Description:
 *
 */
define([
    'angular'
], function (angular) {
    angular.module('SampleTimePickerView', []);
});