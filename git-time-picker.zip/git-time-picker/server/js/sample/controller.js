/**
 * Created by Barinderjit Singh on 20/10/16.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'server/js/sample/sample'
], function (angular, moment) {
    angular.module('SampleTimePickerView')
        .controller('SampleTimePickerViewController', ['$scope', '$filter', function ($scope, $filter) {
            
			$scope.placeholderValue = true;
			$scope.hideFormat = true;
			
			$scope.timePickerConfigSample = {
                'isMeridian': true,
                'currentDate': new Date(),
				'setHour': function (val) {
					$scope.placeholderValue = false;
					$scope.hourValue = val;
					
				},
				'setMinute': function (val) {
					$scope.placeholderValue = false;
					$scope.hideFormat = false;
					$scope.minValue = val;
				},
				'setFormat': function (val) {
					$scope.timeFormat = val;
				}
            };
			
			
            
        }]);
});
