/**
 * Created by Barinderjit Singh on 20/10/16.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'text!module/template/template.html',
    'module/js/controller',
    'module/js/timepicker'
], function (angular, moment, template) {
    angular.module('TimePicker').directive('timecatcher', [ function () {
        return {
            restrict: 'EA',
            template: template,
            scope: {
               timePickerConfig: '='
            },
            controller: 'TimePickerController',
            link: function (scope, element, attrs) {
				
				scope.hourFormat = '';
				var formatHours = function(hourValue) {
					scope.hourModel = hourValue;
					if (scope.hourModel < 10) {
						scope.hourModel = '0' + scope.hourModel;
					}
					scope.timePickerConfig.setHour(scope.hourModel);
					
				}
				
				scope.toggleFormatHour = function () {
					
					if (scope.hourFormat == '24H' && scope.hourModel != null) {
						//going to 12 Hour format
						if (scope.hourModel > 12) {
							scope.hourModel -= 12;
							scope.amPmVal = 'PM';
							scope.timePickerConfig.setFormat(scope.amPmVal);
							formatHours(scope.hourModel);
						} else {
							scope.amPmVal = 'AM';
							scope.timePickerConfig.setFormat(scope.amPmVal);
						}
						
					} else {
						//going to 24H Format
						if (scope.hourModel < 12 && scope.hourModel != '') {
							scope.hourModel = parseInt(scope.hourModel) + 12;
							formatHours(scope.hourModel);
						}
					}
										
					var el_12H = angular.element(document.querySelector('.display-format'))[0];
					scope.timePickerConfig.isMeridian = ! scope.timePickerConfig.isMeridian;
					
					if (el_12H.classList.contains('toggle-12Hformat-icon')) {
						angular.element(el_12H).removeClass('toggle-12Hformat-icon');
						angular.element(el_12H).addClass('toggle-24Hformat-icon');
						
					} else {
						angular.element(el_12H).addClass('toggle-12Hformat-icon');
						angular.element(el_12H).removeClass('toggle-24Hformat-icon');
						
					}
				
				};
				
				scope.amPmVal = 'PM';
				scope.timePickerConfig.setFormat('PM');
				scope.toggleAmPm = function () {
					var am_pm_button = angular.element(document.querySelector('.display-AmPm'))[0];
					
					if (am_pm_button.classList.contains('toggle-AmPm-icon')) {
						angular.element(am_pm_button).removeClass('toggle-AmPm-icon');
						angular.element(am_pm_button).addClass('button-value');
						angular.element(am_pm_button).parent().addClass('text-right');
						angular.element(am_pm_button).parent().removeClass('text-left');
						scope.amPmVal = 'AM';
						scope.timePickerConfig.setFormat('AM');
						
					} else {
						angular.element(am_pm_button).addClass('toggle-AmPm-icon');
						angular.element(am_pm_button).removeClass('button-value');
						angular.element(am_pm_button).parent().addClass('text-left');
						angular.element(am_pm_button).parent().removeClass('text-right');
						scope.amPmVal = 'PM';
						scope.timePickerConfig.setFormat('PM');
						
					}
				};
				
				scope.getHours = function (hourVal) {
					scope.hourModel = hourVal;
					scope.timePickerConfig.setHour(hourVal);
				
					if (angular.element(document.querySelector('.toggleHours'))[0].classList.contains('in')) {
						angular.element(document.querySelector('.toggleHours')).removeClass('in');
					} else {
						angular.element(document.querySelector('.toggleHours')).addClass('in');
					}
					
				};
		
				scope.getMinutes = function (minVal) {
					scope.minuteModel = minVal;
					scope.timePickerConfig.setMinute(minVal);
					
					if (angular.element(document.querySelector('.toggleMinutes'))[0].classList.contains('in')) {
						angular.element(document.querySelector('.toggleMinutes')).removeClass('in');
					} else {
						angular.element(document.querySelector('.toggleMinutes')).addClass('in');
					}
					
				};
				
            }
        };

    }]);
});
