/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 *
 */

define([
    'angular',
    'moment',
    'module/js/timepicker'
], function (angular) {
    angular.module('TimePicker').controller('TimePickerController', ['$scope','$element', function ($scope, $element) {
		       		
		$scope.hourModel = '';
		$scope.minuteModel = '';
		
		$scope.start = 0;
		$scope.end = 62;
		$scope.items = [];
		
		for (var i = 0; i <= $scope.end; i++) {
			if (i < 10) {
				i = '0'+i;
			}
			$scope.items.push(i);
		}
		
		$scope.updateHours = function (event) {
			if (!!$scope.timePickerConfig.isMeridian) {
				if ($scope.hourModel === 'undefined' || $scope.hourModel === '') {
					//checking first digit, must be 0-1
					if (event.which !== 48 && event.which !== 49) {
						event.preventDefault();
					}
				} else if ($scope.hourModel.length) {
					if ($scope.hourModel === '0') {
						// if first is 0, then next would be 1-9
						if (event.which <= 48 || event.which > 57) {
							event.preventDefault();
						}
					} else if ($scope.hourModel === '1') {
						// if first is 1, then next would be 0-2
						if (event.which < 48 || event.which > 50) {
							event.preventDefault();
						}
					}
				}
			} else {
				// in 24 H format
				if ($scope.hourModel === 'undefined' || $scope.hourModel === '') {
					if (event.which !== 48 && event.which !== 49 && event.which !== 50) {
						event.preventDefault();
					}
				} else if ($scope.hourModel.length) {
					if ($scope.hourModel === '0') {
						if (event.which < 48 || event.which > 57) {
							event.preventDefault();
						}
					} else if ($scope.hourModel === '1') {
						if (event.which < 48 || event.which > 57) {
							event.preventDefault();
						}
					} else if ($scope.hourModel === '2') {
						if (event.which < 48 || event.which > 51) {
							event.preventDefault();
						}
					}
				}
			}
		};
		
		$scope.updateMinutes = function (event) {
			if ($scope.minuteModel === 'undefined' || $scope.minuteModel === '') {
				if (!(event.which >= 48 && event.which <= 53)) {
					event.preventDefault();
				}
			} else if ($scope.minuteModel.length) {
				if ($scope.minuteModel === '0' || $scope.minuteModel === '1' || $scope.minuteModel === '2' || $scope.minuteModel === '3' || $scope.minuteModel === '4' || $scope.minuteModel === '5') {
					// if first is 0-5, then next digit would be 0-9, <48 && >57
					if (event.which < 48 || event.which > 57) {
						event.preventDefault();
					}
				}
			}
			
		};
        
    }]).filter('slice', function () {
		return function (arr, start, end) {
			return arr.slice(start, end);
		}
	});
	
	
});
